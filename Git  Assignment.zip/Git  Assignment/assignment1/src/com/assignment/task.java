package com.assignment;

import java.util.Scanner;

public class task {
public static void main(String[] args) {
	System.out.println("Welcome Madhupriya");
	Scanner sc=new Scanner(System.in);
	System.out.println("Write Something");
	String s=sc.nextLine();
	System.out.println("GIT TUTORIAL");
	System.out.println("hi");
	
}
}
